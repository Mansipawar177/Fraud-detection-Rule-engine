package com.example.demo.dto;
import lombok.Data;
@Data
public class FraudRuleResponse {
private Long ruleId;
private String ruleName;
private String ruleType;
private  Double thresholdValue;
private Boolean enabled;
private String description;
}
	