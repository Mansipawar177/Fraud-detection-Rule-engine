package com.example.demo.util;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
public class DateTimeUtil {

private static final DateTimeFormatter FORMATTER=DateTimeFormatter.ofPattern("dd-mm-yyyy hh;mm;ss");
public static String format(LocalDateTime DateTime) {
	return DateTime.format(FORMATTER);
}
}