package com.example.demo.repository;
import java.util.Optional;
import java.time.LocalDateTime;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.example.demo.entity.Transaction;
@Repository
public interface TransactionRepository extends JpaRepository<Transaction,Long>{
	Optional<Transaction> findByUserIdAndAmountAndMerchantAndTransactionTime(
			Long userId,
			Double amount,
			String merchant,
			LocalDateTime transactionTime);
	

}
