package com.example.demo.entity;
import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDateTime;
import com.example.demo.enums.PaymentMethod;
import com.example.demo.enums.TransactionStatus;  
@Entity
@Table(name="transactions")
@Data
		public class Transaction {
@Id
@GeneratedValue(strategy=GenerationType.IDENTITY)
private Long transactionId;
@Column(nullable=false)
private Long userId;
@Column(nullable=false)
private Double amount;
private String location;
private String merchant;
@Enumerated(EnumType.STRING)
private TransactionStatus status;
private LocalDateTime transactionTime;
private String deviceId;
@Enumerated(EnumType.STRING)
private PaymentMethod paymentMethod;
}
	
