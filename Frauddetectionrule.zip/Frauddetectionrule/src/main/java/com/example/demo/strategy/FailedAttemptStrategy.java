package com.example.demo.strategy;
import com.example.demo.enums.TransactionStatus;
import org.springframework.stereotype.Component;
import com.example.demo.entity.Transaction;
@Component
public class FailedAttemptStrategy implements FraudStrategy{
	@Override
	public String checkFraud(Transaction transaction) {
		if(transaction.getStatus()==TransactionStatus.FAILED) {
			return"SUSPECIOUS";
		}
		return"SAFE";
		
	}
}
