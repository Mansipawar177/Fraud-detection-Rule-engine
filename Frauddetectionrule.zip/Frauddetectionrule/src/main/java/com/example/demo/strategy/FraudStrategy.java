package com.example.demo.strategy;
import com.example.demo.entity.Transaction;
public interface FraudStrategy {

	String checkFraud(Transaction transaction);
}