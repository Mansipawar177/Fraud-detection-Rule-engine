package com.example.demo.service.impl;
import com.example.demo.entity.FraudRule;
import com.example.demo.repository.FraudRuleRepository;
import com.example.demo.service.FraudRuleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
@Service
public class FraudRuleServiceImpl implements FraudRuleService{
	@Autowired
	private FraudRuleRepository fraudRuleRepository;
	@Override
	public FraudRule saveFraudRule(FraudRule fraudRule) {
		return fraudRuleRepository.save(fraudRule);
	}
	@Override
	public List<FraudRule>getAllFraudRules(){
		return fraudRuleRepository.findAll();
	}
	@Override
	public FraudRule getFraudRuleById(Long id){
		return fraudRuleRepository.findById(id).orElseThrow(()->new RuntimeException("fraud rule not found"));
	}
	@Override
	public FraudRule updateFraudRule(Long id,FraudRule fraudRule) {
		FraudRule existing=fraudRuleRepository.findById(id).orElseThrow(()->new RuntimeException("fraud rule not found"));
		
		existing.setRuleName(fraudRule.getRuleName());
		existing.setRuleType(fraudRule.getRuleType());
		existing.setThresholdAmount(fraudRule.getThresholdAmount());
		existing.setEnabled(fraudRule.getEnabled());
		existing.setDescription(fraudRule.getDescription());
		return fraudRuleRepository.save(existing);
	}
	@Override
	public void deleteFraudRule(Long id) {
		fraudRuleRepository.deleteById(id);
	
		
		
	}
}

