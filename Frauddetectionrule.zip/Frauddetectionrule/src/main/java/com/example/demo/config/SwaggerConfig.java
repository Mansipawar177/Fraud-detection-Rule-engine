package com.example.demo.config;



import io.swagger.v3.oas.models.ExternalDocumentation;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SwaggerConfig {

    @Bean
    public OpenAPI fraudDetectionOpenAPI() {

        return new OpenAPI()
                .info(new Info()
                        .title("Fraud Detection Rule Engine API")
                        .description("REST APIs for Fraud Detection Rule Engine")
                        .version("1.0")
                        .contact(new Contact()
                                .name("Mansi Pawar")
                                .email("mansi@example.com")))
                .externalDocs(new ExternalDocumentation()
                        .description("Project Documentation"));

    }
}