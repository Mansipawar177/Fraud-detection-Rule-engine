package com.example.demo.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.example.demo.entity.FraudResult;
import com.example.demo.service.FraudResultService;
@RestController
@RequestMapping("/fraud-result")
public class FraudResultController {
	@Autowired
	private FraudResultService fraudResultService;
	@PostMapping
	public FraudResult saveFraudResult(@RequestBody FraudResult fraudResult) {
		return fraudResultService.saveFraudResult(fraudResult);
	}
	@GetMapping
	public List<FraudResult>getAllFraudResult(){
		return fraudResultService.getAllFraudResults();
	}
	@GetMapping("/{id}")
	public FraudResult getFraudReultById(@PathVariable Long id) {
		return fraudResultService.getFraudResultById(id);
	}
	@DeleteMapping("/{id}")
	public String deleteFraudResult(@PathVariable Long id) {
		fraudResultService.deleteFraudResult(id);
		return"fraud result deleted successfully";
	}
}

	