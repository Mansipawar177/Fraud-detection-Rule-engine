package com.example.demo.dto;
import java.time.LocalDateTime;
import lombok.Data;
@Data
public class TransactionRequestDTO {
	private Long userId;
	private Double amount;
	private String location;
	private String merchant;
	private String status;
	private String deviceId;
	private String paymentMethod;
	private LocalDateTime transactionTime;
}