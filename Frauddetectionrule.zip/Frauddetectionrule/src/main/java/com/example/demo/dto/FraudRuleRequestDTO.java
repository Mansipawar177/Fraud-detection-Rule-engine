package com.example.demo.dto;
import lombok.Data;
@Data
public class FraudRuleRequestDTO {
private String ruleName;
private String ruleType;
private Double thresholdValue;
private Boolean enabled;
private String description;
}

	