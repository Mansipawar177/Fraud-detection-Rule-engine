package com.example.demo.strategy;
import org.springframework.stereotype.Component;
import com.example.demo.entity.Transaction;
@Component
public class GeoLocationStrategy implements FraudStrategy{
	@Override
	public String checkFraud(Transaction transaction) {
		if("unknown".equalsIgnoreCase(transaction.getLocation())) {
			return"FRAUD";
		}
		return "SAFE";
		}
	}


	