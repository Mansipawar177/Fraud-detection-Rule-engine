package com.example.demo.dto;
import java.time.LocalDateTime;
import lombok.Data;
@Data
public class FraudResultResponse {

	private Long resultId;
	private Long transactionId;
	private String riskLvel;
	private String reasoncode;
	private LocalDateTime processedTime;

}
