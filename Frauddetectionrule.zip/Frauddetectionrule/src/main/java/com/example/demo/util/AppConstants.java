package com.example.demo.util;

public class AppConstants {
public static final double high_amount_limit=50000.0;
public static final int max_failed_attempts=3;
public static final int max_transactions_per_minute=5;


	
}

