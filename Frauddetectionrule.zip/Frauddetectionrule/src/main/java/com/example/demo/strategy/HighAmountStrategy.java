package com.example.demo.strategy;
import com.example.demo.entity.Transaction;
import org.springframework.stereotype.Component;
@Component
public class HighAmountStrategy implements FraudStrategy{

	@Override
	public String checkFraud(Transaction transaction) 
	{if(transaction.getAmount()>5000) {
		return"SUSPECIOUS";
	}
	return"SAFE";
	
	}
		
	}