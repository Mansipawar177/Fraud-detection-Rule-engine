package com.example.demo.entity;
import jakarta.persistence.*;
import lombok.Data;
import com.example.demo.enums.RiskLevel;
import java.time.LocalDateTime;
@Data
@Entity
@Table(name="fraud_result")
public class FraudResult {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long resultId;
	@OneToOne
	@JoinColumn(name="transaction_id")
	private Transaction transaction;
	@Enumerated(EnumType.STRING)
	private RiskLevel riskLevel;
	private String reasonCode;
	private LocalDateTime processedTime; 
}
