package com.example.demo.enums;

public enum RiskLevel {
SAFE,
SUSPECIOUS,
FRAUD
}
