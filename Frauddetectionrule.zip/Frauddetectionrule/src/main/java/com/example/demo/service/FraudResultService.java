package com.example.demo.service;
import java.util.List;
import com.example.demo.entity.FraudResult;
public interface FraudResultService {
	FraudResult saveFraudResult(FraudResult fraudResult);
	List<FraudResult>getAllFraudResults();
    FraudResult getFraudResultById(Long id);
void deleteFraudResult(Long id);
}
