package com.example.demo.dto;
import lombok.Data;
@Data
public class FraudResultRequest {
private Long transactionId;
private String riskLevel;
private String reasonCode;
}
	