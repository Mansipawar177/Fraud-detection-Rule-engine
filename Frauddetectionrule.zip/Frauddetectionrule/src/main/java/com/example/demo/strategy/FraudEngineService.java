package com.example.demo.strategy;
import org.springframework.stereotype.Component;
import com.example.demo.entity.Transaction;
import com.example.demo.enums.TransactionStatus;
@Component
public class FraudEngineService implements FraudStrategy{
	
	@Override
	public String checkFraud(Transaction transaction) {
		if(transaction.getStatus()==TransactionStatus.FAILED) {
			return"SUSPECIOUS";
		}
	return"SAFE";
		
	}


}
