package com.example.demo.dto;
import java.time.LocalDateTime;
import lombok.Data;
@Data
public class TransactionResponseDTO {
private Long transactionId;
private Long userID;
private Double amount;
private String location;
private String merchant;
private String status;
private LocalDateTime transactionTime;
private String deviceId;
private String paymentMthod;
}
	