package com.example.demo.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.example.demo.entity.FraudResult;
@Repository

public interface FraudResultRepository extends JpaRepository<FraudResult,Long>{

}
