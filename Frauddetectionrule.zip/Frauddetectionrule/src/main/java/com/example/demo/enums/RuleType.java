package com.example.demo.enums;

public enum RuleType {
HIGH_AMOUNT,
FREQUENT_TRANSACTION,
GEO_LOCATION,
FAILED_ATTEMPT
}
