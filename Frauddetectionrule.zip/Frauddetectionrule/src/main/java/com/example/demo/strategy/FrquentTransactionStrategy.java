package com.example.demo.strategy;
import org.springframework.stereotype.Component;
import com.example.demo.entity.Transaction;
@Component
public class FrquentTransactionStrategy implements FraudStrategy{

@Override
public String checkFraud(Transaction transaction) {
	return"SAFE";
}
}