package com.example.demo.service;
import java.util.List;
import com.example.demo.entity.FraudRule;
public interface FraudRuleService {
	FraudRule saveFraudRule(FraudRule fraudRule);
	List<FraudRule>getAllFraudRules();
	FraudRule getFraudRuleById(Long id);
	FraudRule updateFraudRule(Long id,FraudRule fraudRule);
	void deleteFraudRule(Long id);
}

	