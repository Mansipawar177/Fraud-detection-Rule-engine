package com.example.demo.service.impl;
import com.example.demo.entity.FraudResult;
import com.example.demo.repository.FraudResultRepository;
import com.example.demo.enums.RiskLevel;
import java.util.Optional;
import java.time.LocalDateTime;
import com.example.demo.exception.DuplicateTransactionException;
import com.example.demo.entity.Transaction;
import com.example.demo.repository.TransactionRepository;
import com.example.demo.service.TransactionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Map;
@Service
public class TransactionServiceImpl implements TransactionService{
	@Autowired
	private TransactionRepository repository;
@Autowired
private FraudResultRepository fraudResultRepository;
	@Override
	public List<Transaction>getAllTransactions() {
		return repository.findAll();
	}
	@Override
	public Transaction getTransactionById(Long id){
		return repository.findById(id).orElseThrow();
	}
	@Override
	public Transaction saveTransaction(Transaction transaction) {
		Optional<Transaction>existingTransaction=repository.findByUserIdAndAmountAndMerchantAndTransactionTime(
				transaction.getUserId(),
				transaction.getAmount(),
				transaction.getMerchant(),
				transaction.getTransactionTime());
		if(existingTransaction.isPresent()) {
			throw new DuplicateTransactionException("duplicate Transaction detected.Existing Transaction ID:"+existingTransaction.get().getTransactionId());
		}
		Transaction savedTransaction=repository.save(transaction);
		FraudResult result=new FraudResult();
		result.setTransaction(savedTransaction);
		if(savedTransaction.getAmount()>5000) {
			result.setRiskLevel(RiskLevel.SUSPECIOUS);
		}else {
			result.setRiskLevel(RiskLevel.SAFE);
		}
		
	result.setProcessedTime(LocalDateTime.now());
	fraudResultRepository.save(result);
	return savedTransaction;
		
	}
	@Override
	public Transaction updateTransaction(Long id,Transaction transaction) {
		Transaction t=repository.findById(id).orElseThrow();
		t.setUserId(transaction.getUserId());
		t.setAmount(transaction.getAmount());
		t.setLocation(transaction.getLocation());
		t.setMerchant(transaction.getMerchant());
		t.setStatus(transaction.getStatus());
		t.setTransactionTime(transaction.getTransactionTime());
		t.setDeviceId(transaction.getDeviceId());
		t.setPaymentMethod(transaction.getPaymentMethod());
		return repository.save(t);
		
	}
	@Override
	public void deleteTransaction(Long id) {
		repository.deleteById(id);
	}
}

	