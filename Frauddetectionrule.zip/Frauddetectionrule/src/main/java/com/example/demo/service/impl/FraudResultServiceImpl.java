package com.example.demo.service.impl;
import com.example.demo.entity.FraudResult;
import com.example.demo.repository.FraudResultRepository;
import com.example.demo.service.FraudResultService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
@Service
public class FraudResultServiceImpl implements FraudResultService{
	@Autowired
	private FraudResultRepository fraudResultRepository;
	@Override
	public FraudResult saveFraudResult(FraudResult fraudResult) {	

		return fraudResultRepository.save(fraudResult);
	
	}
	@Override
	public List<FraudResult>getAllFraudResults(){
		return fraudResultRepository.findAll();
	}
	@Override
	public FraudResult getFraudResultById(Long id) {
		return fraudResultRepository.findById(id).orElseThrow(()->new RuntimeException("fraud result not found"));
	}
	@Override
	public void deleteFraudResult(Long id) {
		fraudResultRepository.deleteById(id);
	}
}

	