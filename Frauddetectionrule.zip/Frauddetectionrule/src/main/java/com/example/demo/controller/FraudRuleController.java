package com.example.demo.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.example.demo.entity.FraudRule;
import com.example.demo.service.FraudRuleService;

@RestController
@RequestMapping("/fraud-rules")

public class FraudRuleController {
@Autowired
private FraudRuleService fraudRuleService;
@PostMapping
public FraudRule SaveFraudRule(@RequestBody FraudRule fraudRule) {
	return fraudRuleService.saveFraudRule(fraudRule);
}
@GetMapping
public List<FraudRule>getAllFraudRules(){
	return fraudRuleService.getAllFraudRules();
}
@GetMapping("/{id}")
public FraudRule getFraudRuleById(@PathVariable Long id) {
	return fraudRuleService.getFraudRuleById(id);
}
@PutMapping("/{id}")
public FraudRule updateFraudRule(@PathVariable Long id,
		@RequestBody FraudRule fraudRule) {
	return fraudRuleService.updateFraudRule(id,fraudRule);
}
@DeleteMapping("/{id}")
public String deleteFraudRule(@PathVariable Long id) {
	fraudRuleService.deleteFraudRule(id);
	return"fraud rule deleted successfully";
}
}
	