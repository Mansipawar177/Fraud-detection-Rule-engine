package com.example.demo.entity;
import jakarta.persistence.*;
import lombok.Data;
@Entity
@Table(name="fraud_rule")
@Data

public class FraudRule {
@Id
@GeneratedValue(strategy=GenerationType.IDENTITY)
private Long ruleId;
@Column(nullable=false)
private double thresholdAmount;
private String ruleName;
private String ruleType;
private Boolean enabled;
private String description;
}

	