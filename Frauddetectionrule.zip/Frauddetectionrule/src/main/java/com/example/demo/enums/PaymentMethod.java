package com.example.demo.enums;

public enum PaymentMethod {
UPI,
CREADIT_CARD,
DEBIT_CARD,
NET_BANKING,
WALLET
}
